# julia-github-search
Firefox extension for fast Julia repository search. Entering
```
  jl <query>
```
in the address bar navigates to the top github hit for the repository search query `<query>+language:julia`.

![demonstration](img/anim.gif)
